#include<stdio.h>

int main(){
    int f=100;
    float c=(f-32)/1.8;
    printf("%f\n",c);
    return 0;
}