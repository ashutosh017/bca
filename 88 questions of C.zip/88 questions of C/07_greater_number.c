#include<stdio.h>

int main(){
    int a=4,b=3;
    if(a>b){
        printf("%d\n",a);
    }
    else{
        printf("%d\n",b);
    }
    return 0;
}