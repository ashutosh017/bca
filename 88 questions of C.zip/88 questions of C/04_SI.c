#include<stdio.h>

int main(){
    int p=1000,r=12,t=10,SI;
    SI=(p*r*t)/100;
    printf("%d\n",SI);
    return 0;
}