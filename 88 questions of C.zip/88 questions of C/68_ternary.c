#include<stdio.h>

int main(){
    int a,b;
    printf("Enter a\n");
    scanf("%d",&a);
    printf("Enter b\n");
    scanf("%d",&b);
    (a>b) ? printf("a is greater\n") : printf("b is greater\n");
    return 0;
}