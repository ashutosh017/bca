#include<stdio.h>

int main(){
     int a,z,n=0,save;
     printf("Enter a: ");
     scanf("%d",&a);
     save=a;
     while(a!=0){
        z=a%10;
        n = z*z*z +n;
        a=a/10;
     }
    printf("%d\n",n);
     if(n==save){
        printf("Armstrong\n");
     }
     else{
        printf("Not armstrong\n");
     }
    return 0;
}