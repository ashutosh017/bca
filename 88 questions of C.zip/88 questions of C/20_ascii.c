#include<stdio.h>

int main(){
    char a;
    printf("Enter a\n");
    scanf("%c",&a);
    printf("ascii value of %c is %d\n",a,a);
    return 0;
}