#include<stdio.h>

int main(){
    int a=4,b=3,c;
    c=a+b;
    printf("%d\n",c);
    return 0;
}