#include<stdio.h>

int main(){
    int f,z;
    printf("Enter f\n");
    scanf("%d",&f);
        z=f;
    for(int i=0;i<f;i++){
        z = (z-1) + (z-2);
        printf("%d ",z);
        z--;

    }
    printf("\n");
    
    
    return 0;
}