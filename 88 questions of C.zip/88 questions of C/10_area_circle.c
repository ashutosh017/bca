#include<stdio.h>

int main(){
    int r=10;
    float area;
    area = 3.14 * r * r;
    printf("%0.1f unit sqr\n",area);
    return 0;
}