#include<stdio.h>
#include<math.h>

int main(){
    int num;
    float sqrRoot;
    printf("Enter the value of num\n");
    scanf("%d\n",&num);
    
    printf("%f\n",sqrRoot);

    return 0;
}