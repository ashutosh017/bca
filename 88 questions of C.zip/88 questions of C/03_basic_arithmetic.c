#include<stdio.h>

int main(){
    int a,b,c,d,e,f;
    a=4,b=2;
    c=a+b;
    d=a-b;
    e=a*b;
    f=a/b;
    printf("c=%d\nd=%d\ne=%d\nf=%d\n",c,d,e,f);
    return 0;
}