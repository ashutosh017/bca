#include<stdio.h>
void hi(){
    printf("hi\n");
}
int main(){
    hi();
    return 0;
}